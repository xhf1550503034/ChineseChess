#include "singlegame.h"
#include<QTimer>
#include<board.h>
#include<step.h>
#include<qDebug>
#include<QVector>
Singlegame::Singlegame(QWidget *parent) : Board(parent)
{
       _level = 4;
       connect(btback,&QPushButton::released,this,&Singlegame::back);
}
//Singlegame::Singlegame(){}
void Singlegame::back()
{
         if (!this->redturn)//红方才能悔棋
         Board::backStep();

}
void Singlegame::click(int id, int row, int col) {

         if (!this->redturn)
             return;//不是红方走 即不是人走 点了也没效果

         Board::click(id, row, col);


         if (!this->redturn) {
             //启动0.1秒定时器，在0.1秒后电脑再思考
             QTimer::singleShot(500, this, SLOT(computermove()));

         }//轮到黑方走，即是电脑走
}
void Singlegame::computermove() {

         Step* step = aimove();
         //
         if(s[20]._dead){
             return;
         }
         moveStone(step->moveid, step->rowto, step->colto, step->killid);
         //saveStep(step->moveid, step->killid,step->rowto, step->colto,Board::steps);
         //电脑移动
         if(s[4]._dead)
             return;
         delete step;//电脑走完也要释放step
         selectid = -1;
         update();//刷新界面
}
void Singlegame::getAllPossibleMove(QVector<Step *> &steps) {

         int min = 16, max = 32;//黑棋id从16到31
         if (this->redturn) {
             min = 0, max = 16;//红棋id从0到15
         }
         for (int i = min; i < max; i++) {
             if (s[i]._dead) continue;//去掉死棋
             for (int row = 0; row <= 9; ++row) {
                 for (int col = 0; col <= 8; ++col) {
                     int killid = this->getId(row, col);
                     if (sameColor(killid, i)) continue;//颜色相同 继续遍历

                     if (canmove(i, row, col, killid)) {
                         saveStep(i, killid, row, col, steps);
                     }//颜色不同  判断是否可以移动 如果可以移动 保存到容器中去
                 }
             }
         }

}
void Singlegame::fakemove(Step* step) {

         killStone(step->killid);//吃掉棋子
         moveStone(step->moveid, step->rowto, step->colto);//移动并且换过了下棋方

}
void Singlegame::reliveStone(int id){//已包含在下方backstep函数中
    if(id==-1) return;
    else s[id]._dead=false;

}//恢复子
void Singlegame::unfakemove(Step* step) {

         reliveStone(step->killid);

         moveStone(step->killid,step->rowto,step->colto);
         moveStone(step->moveid, step->rowfrom, step->colfrom);




         //update();
}
     //评价局面分
     //enum TYPE{
     //    CHE,
     //    JIANG,
     //    SHUAI,
     //    ZU,
     //    PAO,
     //    MA,
     //    BING,
     //    SHI,
     //    XIANG
     //};

     int Singlegame::calcScore() {
         int redScore = 0;
         int blackScore = 0;
         static int chessScore[] = {100,1500,1500,20,50,50,20,10,10 };
         //黑棋分的总数-红棋分的总数
         for (int i = 0; i < 16; i++) {
             if (s[i]._dead) continue;
             // qDebug()<<chessScore[s[i]._type]<<" ";
             redScore += chessScore[s[i]._type];
         }//红棋总分
         for (int i = 16; i < 32; i++) {
             if (s[i]._dead) continue;

             blackScore += chessScore[s[i]._type];
         }//黑棋总分
         int score = blackScore - redScore;

         return score;

     }
     int Singlegame::getMaxScore(int level, int curMinScore) {//(int level, int curMinScore)

         if (level == 0)return calcScore();//递归终结条件
         QVector<Step*>step1;
         getAllPossibleMove(step1);
         int maxScore = -100000;
         while (step1.count()) {
             Step* step = step1.last();
             step1.removeLast();
             fakemove(step);//走了一步
             int score = getMinScore(level-1, maxScore);//最小值里的最大值(level-1, maxScore)
             unfakemove(step);
             delete step;
             if (score >= maxScore) {
                 while (step1.count()) {
                     Step* step = step1.last();
                     step1.removeLast();
                     delete step;
                 }
                 return score;
             }
             if (score > maxScore) {
                 maxScore = score;
             }
             //delete step;

         }

         return maxScore;
     }
     //现在看人走之后的局面

     int Singlegame::getMinScore(int level, int curMaxScore) {//(int level, int curMaxScore)

         if (level == 0)return calcScore();//递归终结条件
         int minScore = 100000;
         QVector<Step*>step2;
         getAllPossibleMove(step2);//红棋的所有可能步骤
         while (step2.count()) {
             Step* step = step2.last();
             step2.removeLast();
             fakemove(step);//虚拟走一步
             int score = getMaxScore(level-1, minScore);//计算局面分 最大最小值算法(level-1, minScore)
             unfakemove(step);//走回来
             delete step;
             if (score <= minScore) {
                 while (step2.count()) {
                     Step* step = step2.last();
                     step2.removeLast();
                     delete step;
                 }//剪枝  释放内存
                 return score;
             }
             if (score < minScore) {
                 minScore = score;
             }
             //delete step;//释放内存

         }

         return minScore;
     }
     Step* Singlegame::aimove() {

         /*
          * 1.看看有哪些步骤可以走  canmove
          * 2.试着走一下
          * 3.评估走的结果
          * 4.取最好的结果作为参考
          */
          // 1.看看有哪些步骤可以走  canmove
         Step *ret=NULL;
         QVector<Step*>step3;
         getAllPossibleMove(step3);

         //3.评估走的结果
         int maxScore = -100000;

         while (step3.count()) {
             Step* step = step3.last();
             step3.removeLast();
             fakemove(step);//虚拟走一步
             int score = getMinScore(_level-1, maxScore);//计算局面分 最大最小值算法 加上当前的maxScore 要是后面有局面值小于maxScore无需计算 剪枝
             unfakemove(step);
             // qDebug()<<step->moveid<<" "<<step->killid;
              //qDebug()<<score;

             if (score > maxScore) {

                 if (ret) delete ret;//如果之前ret保存了的话 释放
                 ret = step;
                 maxScore = score;
             }
             else {
                 delete step;
             }
             //qDebug()<<maxScore;
             //取得最小值的最大值
         }//迭代器遍历步骤数组

         return ret;
     }
