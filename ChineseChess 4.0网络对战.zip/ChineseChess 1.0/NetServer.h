#ifndef NETSERVER_H
#define NETSERVER_H
#include "board.h"
#include<QTcpServer>
#include<QTcpSocket>
#include<QLineEdit>
class NetServer: public Board
{

public:
    NetServer();
    QTcpServer *tcpServer;
    QTcpSocket *tcpSocket;
    QLineEdit *lineEditWrite=new QLineEdit(this);
   //virtual void click(int id, int row, int col);
//public slots:
//    void sendMessage();
};

#endif // NETSERVER_H
