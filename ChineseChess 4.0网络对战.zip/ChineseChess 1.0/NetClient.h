#ifndef NETCLIENT_H
#define NETCLIENT_H
#include "board.h"
#include<QTcpSocket>
#include<QLineEdit>
class NetClient: public Board
{

  public:
    NetClient();
    QTcpSocket *tcpSocket;
    //virtual void click(int id, int row, int col);
    QLineEdit *lineEditWrite=new QLineEdit(this);//保存黑方信息
//public slots:
//    void sendMessage();
};

#endif // NETCLIENT_H
