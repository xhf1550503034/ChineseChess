#include "stone.h"

Stone::Stone()
{

}
void Stone::init(int id,bool blackBottom){
    struct {
      int row,col;
      Stone::TYPE type;
  }pos[16]={
    {0,0,Stone::CHE},//0
    {0,1,Stone::MA},//1
    {0,2,Stone::XIANG},//2
    {0,3,Stone::SHI},//3
    {0,4,Stone::JIANG},//4
    {0,5,Stone::SHI},//5
    {0,6,Stone::XIANG},//6
    {0,7,Stone::MA},//7
    {0,8,Stone::CHE},//8
    {2,1,Stone::PAO},//9
    {2,7,Stone::PAO},//10
    {3,2,Stone::BING},//11
    {3,0,Stone::BING},//12
    {3,4,Stone::BING},//13
    {3,6,Stone::BING},//14
    {3,8,Stone::BING}//15

    };
    _id=id;
    _dead=false;
    _red=(id<16);//id小于16是红方
    if(blackBottom){
    if(id<16){
        _row=pos[id].row;
        _col=pos[id].col;
        _type=pos[id].type;

    }
    else{
        _row=9-pos[id-16].row;
        _col=8-pos[id-16].col;
        int id1=id-16;
        if(id1>=11&&id1<=15){
            _type=ZU;
        }
        else if(id1==4){
            _type=SHUAI;
        }
        else{
        _type=pos[id-16].type;
        }
      }
    }
 else{//黑色在上方
        if(id<16){
            _row=9-pos[id].row;
            _col=8-pos[id].col;
            _type=pos[id].type;

        }
        else{
            _row=pos[id-16].row;
            _col=pos[id-16].col;
            int id1=id-16;
            if(id1>=11&&id1<=15){
                _type=ZU;
            }
            else if(id1==4){
                _type=SHUAI;
            }
            else{
            _type=pos[id-16].type;
            }
    }

    }


}
QString Stone::getText(){
    switch (this->_type) {
    case CHE:
        return "车";

    case MA:
        return "马";

    case PAO:
        return "炮";

    case BING:
        return "兵";
    case ZU:
        return "卒";
    case JIANG:
        return "将";

    case SHI:
        return "士";

    case XIANG:
        return "相";
    case SHUAI:
        return "帅";
    default:
        return "错误";
    }
}
