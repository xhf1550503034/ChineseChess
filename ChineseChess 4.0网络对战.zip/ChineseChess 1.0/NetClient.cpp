#include "NetClient.h"
#include<QLineEdit>
#include<QLabel>
#include<QPushButton>
#include<QHostAddress>
#include<QString>
#include"board.h"
#include"step.h"
#include"stone.h"
#include<QDebug>
//#include<QTimer>
NetClient::NetClient()
{   //客户端为黑方
    Board::redturn=true;
//    Board::blackBottom=false;
    QLabel *port=new QLabel(this);
    port->setText("服务器端口:");
    port->move(900,100);
    port->setFixedSize(100,50);
    QLineEdit *lineEditPort=new QLineEdit(this);
    lineEditPort->move(1050,100);
    lineEditPort->setFixedSize(150,50);
    lineEditPort->setText("8888");
    QLabel *ip=new QLabel(this);
    ip->setText("服务器IP:");
    ip->move(900,180);
    ip->setFixedSize(80,50);
    QLineEdit *lineEditIP=new QLineEdit(this);
    lineEditIP->move(1050,180);
    lineEditIP->setFixedSize(150,50);
    lineEditIP->setText("127.0.0.1");
    QPushButton *buttonConnect=new QPushButton(this);
    buttonConnect->setText("连接");
    buttonConnect->move(950,250);
    //QPushButton *buttonSend=new QPushButton(this);
   // buttonSend->setText("发送数据");
    QLineEdit *lineEditRead=new QLineEdit(this);
    lineEditRead->setReadOnly(true);//保存红方信息
    lineEditRead->move(1000,430);
    lineEditRead->setFixedSize(200,50);

    lineEditWrite->move(1000,300);
    lineEditWrite->setFixedSize(200,50);
    QLabel *lb=new QLabel(this);
    lb->setText("黑方信息:");
    lb->move(900,300);
    lb->setFixedSize(80,50);
    QLabel *lw=new QLabel(this);
    lw->setText("红方信息:");
    lw->move(900,430);
    lw->setFixedSize(80,50);
    setWindowTitle("象棋客户端黑方");
    setFixedSize(1300,1050);
    tcpSocket=NULL;
    //分配空间 指定父对象
    tcpSocket=new QTcpSocket(this);
    connect(buttonConnect,&QPushButton::clicked,[=](){
        QString IP=lineEditIP->text();
        qint16 port=lineEditPort->text().toInt();
        //主动和服务器建立连接
        tcpSocket->connectToHost(QHostAddress(IP),port);
    });
    connect(tcpSocket,&QTcpSocket::connected,[=](){
        lineEditRead->setText("成功和服务器建立连接");
    });
    connect(tcpSocket,&QTcpSocket::readyRead,[=](){
        //获取对方发送的内容
        QByteArray array=tcpSocket->readAll();

//         char ch=',';
//         char ch1='-';
//         qDebug()<<",  "<<(int)ch<<" "<<"- "<<(int)ch1; 44 45
        lineEditRead->setText(array);
        char *ch=array.data();
          //qDebug()<<"ch[0]"<<ch[0]<<","<<"ch[2]"<<ch[2];
        int c0=(int)ch[0]-48;
       int c1=(int)ch[1]-48;
       int c2=(int)ch[2]-48;
       int c3=(int)ch[3]-48;
       int c4=(int)ch[4]-48;
       int c5=(int)ch[5]-48;
       int c6=(int)ch[6]-48;
       int c7=(int)ch[7]-48;
       int c8=(int)ch[8]-48;
       if(c1<0&&c2>=0&&c3<0){//1,2,3,4
           Board::killStone(c2);
           Board::moveStone(c0,c4,c6);
            // qDebug()<<"c1执行！";
       }
       else if(c1<0&&c2<0&&c3>=0){//1,-1,3,4
           Board::killStone(-1);
           Board::moveStone(c0,c5,c7);
           //qDebug()<<"c2执行！";
       }
       else if(c1>=0&&c2<0&&c3>=0&&c4<0){//11,2,3,4
           Board::killStone(c3);
           int i=c0*10+c1;
           Board::moveStone(i,c5,c7);
           //qDebug()<<"c3执行！";
       }
       else if(c1>0&&c2<0&&c3>=0&&c4>=0){//11,22,3,4
           int i1=c3*10+c4;
           Board::killStone(i1);
           int i2=c0*10+c1;
           Board::moveStone(i2,c6,c8);
           //qDebug()<<"c4执行！";
       }
       else if(c1>=0&&c2<0&&c3<0&&c4>=0){//11,-1,3,4

           Board::killStone(-1);
           int i=c0*10+c1;
            //selectid=i;
           Board::moveStone(i,c6,c8);
           //qDebug()<<"c5执行！";
       }
       else if(c1<0&&c2>=0&&c3>=0&&c4<0){//5,22,3,4
           int i=c2*10+c3;
           Board::killStone(i);
           Board::moveStone(c0,c5,c7);
           //qDebug()<<"c6执行！";
       }
      update();
      //QTimer::singleShot(1000, this, SLOT(sendMessage()));


});

    connect(this,&Board::mySignal,this,[=](){
            Step* step =Board::steps.last();
            QString str="";
            str+=QString::number(step->moveid);
            str+=",";
            str+=QString::number(step->killid);
            str+=",";
            str+=QString::number(step->rowto);
            str+=",";
            str+=QString::number(step->colto);
            str+=",";
            str+=QString::number(step->rowfrom);
            str+=",";
            str+=QString::number(step->colfrom);
            lineEditWrite->setText(str);
            tcpSocket->write(str.toUtf8().data());
        });

}

