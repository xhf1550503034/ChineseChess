#include "NetServer.h"
#include<QLineEdit>
#include<QLabel>
#include<QPushButton>
#include<QTcpServer>
#include<QTcpSocket>
#include<QDebug>
#include<stone.h>
#include<QTimer>
NetServer::NetServer()
{//服务器端用做红方
     Board::redturn=true;
     //Board::setBlackBottom(false);
//    for(int i=0;i<32;i++){
//         s[i].init(i,false);
//     }

    tcpServer=NULL;
    tcpSocket=NULL;
    tcpServer=new QTcpServer(this);
    tcpServer->listen(QHostAddress::Any,8888);//监听
    //QPushButton *buttonSend=new QPushButton(this);
//    buttonSend->setText("发送数据");
    QLineEdit *lineEditRead=new QLineEdit(this);
     lineEditRead->setReadOnly(true);
    lineEditRead->move(1000,300);
    lineEditRead->setFixedSize(200,50);//保存黑方信息

    lineEditWrite->move(1000,430);//红方信息
    lineEditWrite->setFixedSize(200,50);
    QLabel *lb=new QLabel(this);
    lb->setText("黑方信息:");
    lb->move(900,300);
    lb->setFixedSize(80,50);
    QLabel *lw=new QLabel(this);
    lw->setText("红方信息:");
    lw->move(900,430);
    lw->setFixedSize(80,50);
    setWindowTitle("服务器:8888红方");
    setFixedSize(1300,1050);
 connect(tcpServer,&QTcpServer::newConnection,[=](){
        //取出建立好连接的套接字
        tcpSocket=tcpServer->nextPendingConnection();//当前最近的那个套接字
        //获取对方的IP和端口
        QString ip=tcpSocket->peerAddress().toString();
        qint16 port=tcpSocket->peerPort();
        QString temp=QString("[%1:%2]:成功连接").arg(ip).arg(port);
        lineEditRead->setText(temp);
        //取出以后才能传送数据
        connect(tcpSocket,&QTcpSocket::readyRead,[=](){
            //从通信套接字中取出内容
            QByteArray array=tcpSocket->readAll();
            lineEditRead->setText(array);
            char *ch=array.data();
              //qDebug()<<"ch[0]"<<ch[0]<<","<<"ch[2]"<<ch[2];
            int c0=(int)ch[0]-48;
           int c1=(int)ch[1]-48;
           int c2=(int)ch[2]-48;
           int c3=(int)ch[3]-48;
           int c4=(int)ch[4]-48;
           int c5=(int)ch[5]-48;
           int c6=(int)ch[6]-48;
           int c7=(int)ch[7]-48;
           int c8=(int)ch[8]-48;
           if(c1<0&&c2>=0&&c3<0){//1,2,3,4
               Board::killStone(c2);
               Board::moveStone(c0,c4,c6);
                 //qDebug()<<"s1执行！";
           }
           else if(c1<0&&c2<0&&c3>=0){//1,-1,3,4
               Board::killStone(-1);
               Board::moveStone(c0,c5,c7);
              // qDebug()<<"s2执行！";
           }
           else if(c1>=0&&c2<0&&c3>=0&&c4<0){//11,2,3,4
               Board::killStone(c3);
               int i=c0*10+c1;
               Board::moveStone(i,c5,c7);
               //qDebug()<<"s3执行！";
           }
           else if(c1>=0&&c2<0&&c3>=0&&c4>=0){//11,22,3,4
               int i1=c3*10+c4;
               Board::killStone(i1);
               int i2=c0*10+c1;
               Board::moveStone(i2,c6,c8);
               //qDebug()<<"s4执行！";
           }
           else if(c1>=0&&c2<0&&c3<0&&c4>=0){//11,-1,3,4


               Board::killStone(-1);
               int i=c0*10+c1;
               // selectid=i;
               Board::moveStone(i,c6,c8);
             //  qDebug()<<"s5执行！";
           }
           else if(c1<0&&c2>=0&&c3>=0&&c4<0){//5,22,3,4
               int i=c2*10+c3;
               Board::killStone(i);
               Board::moveStone(c0,c5,c7);
              // qDebug()<<"s6执行！";
           }
          update();
           //QTimer::singleShot(1000, this, SLOT(sendMessage()));

        });
});

   connect(this,&Board::mySignal,[=](){
        Step* step =Board::steps.last();
        QString str="";
        str+=QString::number(step->moveid);
        str+=",";
        str+=QString::number(step->killid);
        str+=",";
        str+=QString::number(step->rowto);
        str+=",";
        str+=QString::number(step->colto);
        str+=",";
        str+=QString::number(step->rowfrom);
        str+=",";
        str+=QString::number(step->colfrom);
        lineEditWrite->setText(str);
        tcpSocket->write(str.toUtf8().data());
    });

}
