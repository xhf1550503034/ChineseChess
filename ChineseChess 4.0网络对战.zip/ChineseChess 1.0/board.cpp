#include "board.h"
#include<QPainter>
#include<QDebug>
#include<QPoint>
#include<QMouseEvent>
#include<QVector>
#include<step.h>
#include<QPushButton>
#include<QMessageBox>
#include<QApplication>
#include<QTimer>
Board::Board(QWidget *parent) : QWidget(parent)
{    //setBlackBottom(true);
    for(int i=0;i<32;i++){
        s[i].init(i,blackBottom);
    }
   selectid=-1;
   redturn=true;

   btback = new QPushButton;
   btback->setText("悔棋");
   btback->move(1000,500);
   btback->setParent(this);
   connect(btback,&QPushButton::released,[=](){
       Board::backStep();
   });
   //this->resize(800,800);
}

void Board::paintEvent(QPaintEvent *){
       QPainter painter(this);
//绘制棋盘
       int d=90;
       r=d/2;

//首先绘制横线
       for(int i=1;i<=10;i++){
           painter.drawLine(QPoint(d,i*d),QPoint(9*d,i*d));
       }
//接下来绘制竖线
       for(int i=1;i<=9;i++){
           if(i==1||i==9)
              painter.drawLine(QPoint(i*d,d),QPoint(i*d,10*d));
           else{
               painter.drawLine(QPoint(i*d,d),QPoint(i*d,5*d));
                painter.drawLine(QPoint(i*d,6*d),QPoint(i*d,10*d));
           }
       }

       //画将和帅的九宫格
       painter.drawLine(QPoint(4*d,1*d),QPoint(6*d,3*d));
       painter.drawLine(QPoint(6*d,1*d),QPoint(4*d,3*d));
       painter.drawLine(QPoint(4*d,8*d),QPoint(6*d,10*d));
       painter.drawLine(QPoint(6*d,8*d),QPoint(4*d,10*d));

       //画出棋盘两边的兵的位置样式
              painter.drawLine(QPoint(d+5,4*d+5),QPoint(d+5,4*d+10));
              painter.drawLine(QPoint(d+5,4*d+5),QPoint(d+10,4*d+5));
              painter.drawLine(QPoint(d+5,4*d-5),QPoint(d+5,4*d-10));
              painter.drawLine(QPoint(d+5,4*d-5),QPoint(d+10,4*d-5));

              painter.drawLine(QPoint(d+5,7*d+5),QPoint(d+5,7*d+10));
              painter.drawLine(QPoint(d+5,7*d+5),QPoint(d+10,7*d+5));
              painter.drawLine(QPoint(d+5,7*d-5),QPoint(d+5,7*d-10));
              painter.drawLine(QPoint(d+5,7*d-5),QPoint(d+10,7*d-5));

              painter.drawLine(QPoint(9*d-5,4*d-5),QPoint(9*d-5,4*d-10));
              painter.drawLine(QPoint(9*d-5,4*d-5),QPoint(9*d-10,4*d-5));
              painter.drawLine(QPoint(9*d-5,4*d+5),QPoint(9*d-5,4*d+10));
              painter.drawLine(QPoint(9*d-5,4*d+5),QPoint(9*d-10,4*d+5));

              painter.drawLine(QPoint(9*d-5,7*d-5),QPoint(9*d-5,7*d-10));
              painter.drawLine(QPoint(9*d-5,7*d-5),QPoint(9*d-10,7*d-5));
              painter.drawLine(QPoint(9*d-5,7*d+5),QPoint(9*d-5,7*d+10));
              painter.drawLine(QPoint(9*d-5,7*d+5),QPoint(9*d-10,7*d+5));


             //画出炮和兵的棋盘效果
              paintFourLine(painter,2*d,3*d);
              paintFourLine(painter,8*d,3*d);
              paintFourLine(painter,2*d,8*d);
              paintFourLine(painter,8*d,8*d);
              paintFourLine(painter,3*d,4*d);
              paintFourLine(painter,5*d,4*d);
              paintFourLine(painter,7*d,4*d);
              paintFourLine(painter,3*d,7*d);

              paintFourLine(painter,5*d,7*d);
              paintFourLine(painter,7*d,7*d);

              for(int i=0;i<32;i++){
                  drawStone(painter,i);
              }


}
//画出类似炮和兵的初始类棋盘
void Board::paintFourLine(QPainter& painter, int x,int y){
    painter.drawLine(QPoint(x-5,y-5),QPoint(x-5,y-10));
    painter.drawLine(QPoint(x-5,y-5),QPoint(x-10,y-5));
    painter.drawLine(QPoint(x+5,y+5),QPoint(x+5,y+10));
    painter.drawLine(QPoint(x+5,y+5),QPoint(x+10,y+5));
    painter.drawLine(QPoint(x+5,y-5),QPoint(x+5,y-10));
    painter.drawLine(QPoint(x+5,y-5),QPoint(x+10,y-5));
    painter.drawLine(QPoint(x-5,y+5),QPoint(x-5,y+10));
    painter.drawLine(QPoint(x-5,y+5),QPoint(x-10,y+5));
}

//返回象棋棋盘行列对应的像素坐标
QPoint Board::center(int row, int col){
     QPoint ret;
     ret.rx()=(col+1)*r*2;
     ret.ry()=(row+1)*r*2;
     return ret;
}
QPoint Board::center(int id){
    return center(s[id]._row,s[id]._col);
}

//绘制棋子的函数
void Board::drawStone(QPainter& painter,int id){
    if(s[id]._dead)
        return;
    QPoint c=center(id);
    QRect rect=QRect(c.x()-r,c.y()-r,r*2,r*2);//创建一个矩形

    if (id == selectid){
        painter.setBrush(QBrush(Qt::gray));//选中的棋子为灰色
    }
    else{
        painter.setBrush(QBrush(QColor(255,255,0)));
        if(s[id]._red){
         painter.setPen(Qt::red);
        }
    else{
         painter.setPen(Qt::black);
        }
    }
   painter.drawEllipse(center(id),r,r);//在center函数提供的坐标上画一个半径为r的圆形
   painter.setFont(QFont("隶书" ,r-10,700));
   painter.drawText(rect,s[id].getText(),QTextOption(Qt::AlignCenter));//使用矩形来写字符
}

 bool Board::getRowCol(QPoint pt){//看点击是否在棋盘上某点的有效范围内

    for (int row= 0; row <= 9;row++) {
        for (int col = 0; col <= 8; col++) {
            QPoint c = center(row, col);
            int dx;
            dx= c.x()-pt.x();
            int dy;
            dy = c.y() - pt.y();
            int dis = dx * dx + dy * dy;
            if (dis < r*r){
                //r为棋子半径
                clickedRow=row;
                clickedCol=col;
                return true;
            }
        }
    }

    return false;
}//函数ok
int Board::getId(int row, int col){

    for (int i = 0; i < 32; i++)
    {
        if (s[i]._row == row && s[i]._col == col){

            return i;

        }
    }
    return -1;
}
 int Board::getStoneCountAtLine(int row1, int col1, int row2, int col2)//计算两点直线间的棋子个数
 {
     int ret = 0;
     if(row1!=row2&&col1!=col2)
         return -1;

     if (row1 == row2&&col1==col2)
         return -1;
     if(row1==row2)//行相同
     {
         int min = col1 < col2 ? col1 : col2;
         int max = col1 < col2 ? col2 : col1;
         for (int col = min + 1; col < max; ++col)
         {
             if (getId(row1, col) != -1) ++ret;
         }
     }
     else//列相同
     {
         int min = row1 < row2 ? row1 : row2;
         int max = row1 < row2 ? row2 : row1;
         for (int row = min + 1; row < max; ++row)
         {
             if (getId(row, col1) != -1) ++ret;
         }
     }

     return ret;
 }
 bool Board::red(int id){
     return s[id]._red;
 }//判断是否是红方棋子
 bool Board::sameColor(int id1, int id2){
     if(id1 == -1 || id2 == -1) return false;

     return red(id1) == red(id2);

 }//判断两个棋子是否同色，同为真
 void Board::killStone(int id){
     if(id==-1) return;
     else {
         //qDebug()<<"注释掉该棋子";
         s[id]._dead=true;
         s[id]._row=-1;
         s[id]._col=-1;
     }

 }//吃子

 void Board::trySelectStone(int id)//挑棋子下并显示在界面上
 {   // qDebug()<<"第一次选中棋子，更新selectid";
     if(id == -1)
         return;

     if(red(id)!=redturn) return;//是红方棋子但是不是红方下，或者是黑方棋子但是不是黑方下 这时候棋子不能选中

     selectid = id;
     //qDebug()<<selectid;
     update();
 }
 void Board::tryMoveStone(int killid, int row, int col){
    // qDebug()<<"已经连续点击两下鼠标，看是否能下棋或是另选棋子";
     //qDebug()<<killid;
     if(killid != -1 && sameColor(killid, selectid))
     {
         trySelectStone(killid);
         return;
     }//如果选中的两个棋子是同色的 那么选中第二个棋子

     bool ret = canmove(selectid,row,col,killid);//判断是否可以移动
    // qDebug()<<ret;
     if(ret)
     {   //qDebug()<<"可以移动";
         moveStone(selectid,  row, col,killid);
         //移动
         //saveStep(selectid,killid,row,col,Board::steps);
         selectid = -1;
         update();
     }
 }
 void Board::click(int id, int row, int col)
 {   //qDebug()<<"进入点击处理函数2";

     if(this->selectid == -1)
     {
         trySelectStone(id);//第一次选中棋子
     }
     else
     {
         tryMoveStone(id, row, col);//第二次选定要走的方位
     }
 }
 void Board::click(QPoint pt)
 {   qDebug()<<"进入点击处理函数1";
     int row, col;

     bool bClicked = getRowCol(pt);
     row=clickedRow;
     col=clickedCol;
     if(!bClicked) return;//不是有效范围退出

     int id = getId(row, col);

     click(id, row, col);
 }

 void Board::moveStone(int moveid, int row, int col){
     s[moveid]._row = row;
     s[moveid]._col = col;
     //qDebug()<<"help";
     redturn=!redturn;//动了就换下棋方
 }//移动子
 bool Board::isDead(int id){
     if(id == -1)return true;
     return s[id]._dead;

 }//判断子是否是死的
 void Board::moveStone(int moveid, int row, int col, int killid)//移动子
 {   // qDebug()<<"已确定杀和被杀，下这步棋";
      //qDebug()<<killid;
     saveStep(moveid, killid, row, col, steps);
     emit mySignal();
     //qDebug()<<"释放信号";

     killStone(killid);
     moveStone(moveid, row, col);
 }//移动子
 void Board::saveStep(int moveid,int killid,int row,int col,QVector<Step*>&steps){//在走完一步后即保存步骤
     Step * step = new Step;
     step->moveid = moveid;   //存在问题，即每次开始游戏时都应更新vector
     step->killid = killid;
     step->rowfrom = s[moveid]._row;
     step->colfrom=s[moveid]._col;
     step->rowto = row;
     step->colto=col;
     step->actturn=s[moveid]._red;
     steps.append(step);//存入
 }
 void Board::backStep(){//悔棋回退至上一步，只有上一步下棋的人才可悔棋,点击悔棋应在另一方点击棋盘下棋之前
     if(steps.size()==0) return ;//保存完一步棋后redturn已更新
     Step * step = this->steps.last();//取最后一个元素，也就是上一步
     if(redturn==step->actturn)//点击时下棋方和上一步的行走方不同时才可悔棋
         return ;//下了一步棋后红方就变成黑方了 所以点击以后要变成红方下棋
     if(step->killid==-1){
         s[step->moveid]._row=step->rowfrom;
         s[step->moveid]._col=step->colfrom;
         qDebug()<<s[step->moveid]._row<<" "<<s[step->moveid]._col;

     }
     else{
         s[step->moveid]._row=step->rowfrom;
         s[step->moveid]._col=step->colfrom;
         s[step->killid]._row=step->rowto;
         s[step->killid]._col=step->colto;
         s[step->killid]._dead = false;
         qDebug()<<s[step->moveid]._row<<" "<<s[step->moveid]._col;

     }
     redturn = !redturn;//变成红方下棋
     update();
     steps.removeLast();//从保存内容中去掉上一步
     delete step;
 }

void Board::mouseReleaseEvent(QMouseEvent * ev) {
    QPoint pt=ev->pos();
    //qDebug()<<"鼠标点击有效";
    click(pt);//获得鼠标点击点，调用click事件
    if(s[4]._dead)//将帅被吃掉，则判出胜负
     {
            QMessageBox:: StandardButton result=QMessageBox::information(NULL, "中国象棋", "黑方胜利！",
                                     QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
            switch (result)
            {
              case QMessageBox::Yes:
                QApplication* app;
                app->exit(0);
                break;
              case QMessageBox::No:
                backStep();

            }

     }
     if(s[20]._dead)
     {
            QMessageBox:: StandardButton result=QMessageBox::information(NULL, "中国象棋", "红方胜利！",
                                     QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
            switch (result)
            {
              case QMessageBox::Yes:
                QApplication* app;
                app->exit(0);
                break;
              case QMessageBox::No:
                backStep();
            }
    }
}

//之前就选中过棋子 走棋

//根据位置找棋子，未找到返回-1
bool Board::canmoveShi(int moveid, int row, int col, int killid) {
    /*士，走对角线，限定在九宫格内*/ //ok
    if (s[moveid]._red== true) {
        if (row > 2 )
            return false;
    }
    else{
        if(row<7)
            return false;
    }
    if(col<3) return false;
    if(col>5) return false;
    int r = s[moveid]._row - row;
    int c = s[moveid]._col - col;
    int sum = abs(r)*10 + abs(c);//一个为±1，另一个为0
    if (sum == 11)
        return true;
    return false;
}
bool Board::canmoveZu(int moveid, int row, int col, int killid) {
    /*兵能过河，未过河前只能往前走，无法平走，一步走，不能回退，过河后可以平走*/    int r = s[moveid]._row - row;
   int c = s[moveid]._col - col;
   int sum = abs(r)*10 + abs(c);//一个为±1，另一个为0
    if (sum != 1&&sum!=10)
        return false;

        if (s[moveid]._row < row) return false;//往前走 行减少
        if (s[moveid]._row >= 5&& row == s[moveid]._row) return false;//没过河平着走

   return true;
}
bool Board::canmoveBing(int moveid, int row, int col, int killid) {
    /*兵能过河，未过河前只能往前走，无法平走，一步走，不能回退，过河后可以平走*/    int r = s[moveid]._row - row;
   int c = s[moveid]._col - col;
   int sum = abs(r)*10 + abs(c);//一个为±1，另一个为0
    if (sum != 1&&sum!=10)
        return false;

        if (s[moveid]._row >row) return false;
        if (s[moveid]._row<=4 && row == s[moveid]._row) return false;

   return true;
}

bool Board::canmoveBoss(int moveid, int row, int col, int killid) {
   /*将帅，只能在九宫格内并且一步一格*/   //ok
    if(s[moveid]._type==Stone::JIANG){
        if(killid!=-1&&s[killid]._type==Stone::SHUAI){
            return canmoveChe(moveid,row,col,killid);
        }
   }
  if(s[moveid]._type==Stone::SHUAI){
        if(killid!=-1&&s[killid]._type==Stone::JIANG){
           return canmoveChe(moveid,row,col,killid);
        }
    }

   if (s[moveid]._red== true) {
        if (row > 2 )
           return false;
    }
    else{
        if(row<7)
            return false;
   }

   if(col<3) return false;
    if(col>5) return false;


    int r = s[moveid]._row - row;
    int c = s[moveid]._col - col;
    int sum = abs(r)*10 + abs(c);//一个为±1，另一个为0
    if (sum == 1||sum==10)
        return true;
    return false;
}
bool Board::canmoveMa(int moveid, int row, int col, int killid) {
    /*马走日，若上下左右分别有棋子挡着，则对应的位置不能走*/  //ok



    int r = s[moveid]._row - row;
   int c = s[moveid]._col - col;
    int sum = 10 * abs(r) + abs(c);//一个为±1，一个为±2，为了辨别可以乘一个系数
    if (sum != 12 && sum != 21)
        return false;
    if (sum == 12) {//列相差2,行1,马脚在左右
        if (getId(s[moveid]._row, (s[moveid]._col + col) / 2) !=-1)
              return false;

    }
    else {//列相差1,行2,马脚在上下
       if (getId((s[moveid]._row + row) / 2, s[moveid]._col ) != -1)
              return false;

    }
    return true;
}
bool Board::canmovePao(int moveid, int row, int col, int killid) {
    /*炮走直线，中间必须有一个媒介，才能吃子，位置无限制*/ //ok
    int r = s[moveid]._row - row;
    int c = s[moveid]._col - col;
    int sum = abs(r) + abs(c);//一个为任意值因为已经确保两个棋子都在棋盘上，另一个为0，但不能同时为0；
    int m = r * c;
    if (m != 0 || sum == 0)
        return false;
   int cnt = getStoneCountAtLine(s[moveid]._row, s[moveid]._col, row, col);
   if (killid != -1)//吃子
    {
        if (cnt == 1) return true;
    }
    else//移动
    {
        if (cnt == 0) return true;
    }
 return false;
}
bool Board::canmoveChe(int moveid, int row, int col, int killid) {
   /*车走直线，中间无障碍才能走，位置也没有*/ //ok
    int r = s[moveid]._row - row;
    int c = s[moveid]._col - col;
    int sum = abs(r) + abs(c);//一个为任意值因为已经确保两个棋子都在棋盘上，另一个为0，但不能同时为0；
    int m = r * c;
    if (m != 0 || sum == 0)
        return false;
    int cnt = getStoneCountAtLine(s[moveid]._row, s[moveid]._col, row, col);//返回两点直线间的棋子个数
    if (cnt == 0)
        return true;
   return false;
}
bool Board::canmoveXiang(int moveid, int row, int col, int ) {

    /*象不能过河，有象脚则无法走动，走田字格*/  //OK
    if (s[moveid]._red== true) {
        if (row > 4 )
            return false;
    }
    else{
        if(row < 5)
            return false;
    }
    int r = s[moveid]._row - row;
    int c = s[moveid]._col - col;
    int sum = abs(r)*10 +abs(c);//两个都为±2，为了辨别可以乘一个系数
    if (sum != 22)
        return false;
    int r2 = (s[moveid]._row + row) / 2;
    int c2 = (s[moveid]._col + col) / 2;
    if (getId(r2, c2) != -1)//根据位置查找棋子，若未找到则返回-1；
        return false;
    return true;
}
bool Board::canmove(int moveid, int row, int col, int killid) {
    if (s[moveid]._red == s[killid]._red&&killid!=-1) {//同方棋子不能互吃
        selectid = killid;//退回上一步，继续选择另一个棋子
        update();
        return false;

    }

    switch (s[moveid]._type) {

    case Stone::JIANG:
        return canmoveBoss(moveid, row, col, killid);
        break;
    case Stone::SHUAI:
        return canmoveBoss(moveid, row, col, killid);
        break;
    case Stone::SHI:
        return canmoveShi(moveid, row, col, killid);
        break;
   case Stone::XIANG:
        return canmoveXiang(moveid, row, col, killid);
        break;
    case Stone::MA:
        return canmoveMa(moveid, row, col, killid);
        break;
   case Stone::CHE:
        return canmoveChe(moveid, row, col, killid);
        break;
   case Stone::PAO:
        return canmovePao(moveid, row, col, killid);
       break;
    case Stone::BING:
        return canmoveBing(moveid, row, col, killid);
       break;
    case Stone::ZU:
        return canmoveZu(moveid, row, col, killid);
        break;
       }
    return true;
   }


Board::~Board() {}


