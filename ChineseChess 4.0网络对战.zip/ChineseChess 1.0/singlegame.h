#ifndef SINGLEGAME_H
#define SINGLEGAME_H
#include<step.h>
#include <QWidget>
#include<board.h>
class Singlegame : public Board
{
    Q_OBJECT
public:
    explicit Singlegame(QWidget *parent = nullptr);
       //  Singlegame();
         virtual void click(int id, int row, int col);
         Step* aimove();
         void getAllPossibleMove(QVector<Step *>&steps);//保存所有可能走的步骤
         void fakemove(Step* step);
         void unfakemove(Step* step);
         int calcScore();
         int getMinScore(int level, int curMaxScore );
         int getMaxScore(int level, int curMinScore);
         int _level;

         void reliveStone(int id);
     public slots:
         void back();
         void computermove();
signals:


};

#endif // SINGLEGAME_H
