#ifndef BOARD_H
#define BOARD_H
#include<QMouseEvent>
#include <QWidget>
#include"stone.h"
#include<QVector>
#include<step.h>
#include<QPushButton>
class Board : public QWidget
{
    Q_OBJECT


public:
    QPushButton * btback;
    int selectid;
    bool redturn;
    int clickedRow;
    int clickedCol;
     bool blackBottom=true;
   /*bool getBlackBottom(){
        return blackBottom;
    }
    void setBlackBottom(bool b){
        blackBottom=b;
    }*/
    QVector<Step*>steps;
    explicit Board(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void paintFourLine(QPainter& painter,int x,int y);//画出类似炮和兵的初始类棋盘
    Stone s[32];

    int r;//棋子的半径
    QPoint center(int row,int col);//返回象棋棋盘行列对应的像素坐标
    QPoint center(int id);
     void drawStone(QPainter& painter,int id);
     int getId(int row, int col);
      bool isBottomSide(int id);
      int getStoneCountAtLine(int row1, int col1, int row2, int col2);
      void mouseReleaseEvent(QMouseEvent * ev);
      bool getRowCol(QPoint pt);
      void drawstone(QPainter &painter, int id);
      bool canmove(int moveid, int row, int col, int killid);//与switch顺序相对应
      bool canmoveBoss(int moveid, int row, int col, int killid);
      bool canmoveShi(int moveid, int row, int col, int killid);
      bool canmoveXiang(int moveid, int row, int col, int killid);
      bool canmoveMa(int moveid, int row, int col, int killid);
      bool canmoveChe(int moveid, int row, int col, int killid);
      bool canmovePao(int moveid, int row, int col, int killid);
      bool canmoveBing(int moveid, int row, int col, int killid);
       bool canmoveZu(int moveid, int row, int col, int killid);
      ~Board();
      void saveStep(int moveid,int killid,int row,int col,QVector<Step*>&steps);
     // void backStep();


      //人工智能部分新加,点击事件在鼠标按下事件中调用
      virtual void click(int id, int row, int col);
      void trySelectStone(int id);
      void tryMoveStone(int killid, int row, int col);
      void moveStone(int moveid, int killid, int row, int col);
      void killStone(int id);//吃子
      //void reliveStone(int id);//恢复子
      void moveStone(int moveid, int row, int col);//移动子
      bool red(int id);//判断是否是红方棋子
      bool sameColor(int id1, int id2);//判断两个棋子是否同色
      bool isDead(int id);//判断子是否是死的
      void click(QPoint pt);
signals:
      void mySignal();

public slots:
      void backStep();
};

#endif // BOARD_H
