#include "mainwindow.h"
#include <QApplication>
#include<singlegame.h>
#include"board.h"
#include"NetClient.h"
#include"NetServer.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //Singlegame b;
    //b.setMinimumSize(1500,1000);
    //b.show();
    NetServer s;
    s.show();
    NetClient c;
    c.show();


    return a.exec();
}
