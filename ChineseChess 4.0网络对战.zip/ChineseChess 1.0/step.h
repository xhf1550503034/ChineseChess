#ifndef STEP_H
#define STEP_H


class Step
{
public:
    Step();
    int moveid;
    int killid;
    int rowfrom;
    int colfrom;
    int rowto;
    int colto;
    bool actturn;//true 代表是红方下的棋，false代表黑方下的棋
};

#endif // STEP_H
