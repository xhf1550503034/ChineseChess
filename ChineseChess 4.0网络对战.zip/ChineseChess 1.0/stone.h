#ifndef STONE_H
#define STONE_H

#include<QString>
#include<QDebug>

class Stone
{

 public:
    int _row;
    int _col;
    int _id;
    bool _dead;
    int _type;
    bool _red;
    enum TYPE{
        CHE,
        JIANG,
        SHUAI,
        ZU,
        PAO,
        MA,
        BING,
        SHI,
        XIANG
    };
    Stone();
    void init(int id,bool blackBottom);
    QString getText();

};

#endif // STONE_H
